/// <reference types="vite-plugin-elm-watch/client" />

export type Options<flags>= {
  root: Elm.Root<{ data: unknown, user?: flags }>
  flags?: flags
  confirmNavigationMessage?: string
  nodeId?: string
}

export type ElmLandPorts = {
  // elmLand__setShouldPreventNavigation: Elm.OutgoingPort<boolean>
  // elmLand__showConfirmNavigationDialog: Elm.OutgoingPort<null>
  // elmLand__onUserConfirmedNavigation: Elm.IncomingPort<boolean>
  // Ports only used by Elm Land during development
  elmLand__onMarkdownChanged: Elm.IncomingPort<{ filepath: string, markdown: string }>
}

type RouterOption
  = 'file-based'
  | 'markdown'
  | 'inertia'
  | 'manual'

export function init<ports extends {}, flags>(
  options: Options<flags>
) : Elm.App<ports>

type ElmLand = { init: typeof init }
declare const ElmLand : ElmLand

export default ElmLand