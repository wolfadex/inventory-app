// @ts-check
/// <reference types="./types" />

// COMMON MODULES
const ElmLandHttp = () => `
-- 📦 Standard module for https://elm.land 🌈 --


module ElmLand.Http exposing
    ( Request, get, post, put, delete
    , Expect
    , expectString, expectJson, expectBytes
    , Response, expectStringResponse, expectBytesResponse
    , map, toCmd
    )

{-| A version of "elm/http" that allows you to represent an
HTTP request as a value. Useful when working with effects.

@docs Request, get, post, put, delete

@docs Expect
@docs expectString, expectJson, expectBytes

@docs Response, expectStringResponse, expectBytesResponse

@docs map, toCmd

-}

import Bytes exposing (Bytes)
import Bytes.Decode
import Http
import Json.Decode


type alias Request msg =
    { method : String
    , url : String
    , headers : List Http.Header
    , body : Http.Body
    , expect : Expect msg
    , timeout : Maybe Float
    , tracker : Maybe String
    }


get :
    { url : String
    , decoder : Json.Decode.Decoder value
    , onResponse : Result Http.Error value -> msg
    }
    -> Request msg
get props =
    { method = "GET"
    , url = props.url
    , headers = []
    , body = Http.emptyBody
    , expect = expectJson props.onResponse props.decoder
    , timeout = Nothing
    , tracker = Nothing
    }


post :
    { url : String
    , body : Json.Decode.Value
    , decoder : Json.Decode.Decoder value
    , onResponse : Result Http.Error value -> msg
    }
    -> Request msg
post props =
    { method = "POST"
    , url = props.url
    , headers = []
    , body = Http.jsonBody props.body
    , expect = expectJson props.onResponse props.decoder
    , timeout = Nothing
    , tracker = Nothing
    }


put :
    { url : String
    , body : Json.Decode.Value
    , decoder : Json.Decode.Decoder value
    , onResponse : Result Http.Error value -> msg
    }
    -> Request msg
put props =
    { method = "PUT"
    , url = props.url
    , headers = []
    , body = Http.jsonBody props.body
    , expect = expectJson props.onResponse props.decoder
    , timeout = Nothing
    , tracker = Nothing
    }


delete :
    { url : String
    , decoder : Json.Decode.Decoder value
    , onResponse : Result Http.Error value -> msg
    }
    -> Request msg
delete props =
    { method = "DELETE"
    , url = props.url
    , headers = []
    , body = Http.emptyBody
    , expect = expectJson props.onResponse props.decoder
    , timeout = Nothing
    , tracker = Nothing
    }


map : (msg1 -> msg2) -> Request msg1 -> Request msg2
map fn req =
    { method = req.method
    , url = req.url
    , headers = req.headers
    , body = req.body
    , expect = mapExpect fn req.expect
    , timeout = req.timeout
    , tracker = req.tracker
    }


toCmd : Request msg -> Cmd msg
toCmd req =
    Http.request
        { method = req.method
        , url = req.url
        , headers = req.headers
        , body = req.body
        , expect = toHttpExpect req.expect
        , timeout = req.timeout
        , tracker = req.tracker
        }



-- EXPECT


type alias Response body =
    Http.Response body


expectBytesResponse : (Result error value -> msg) -> (Response Bytes -> Result error value) -> Expect msg
expectBytesResponse toMsg toResult =
    ExpectBytesResponse (toMsg << toResult)


expectStringResponse : (Result error value -> msg) -> (Response String -> Result error value) -> Expect msg
expectStringResponse toMsg toResult =
    ExpectStringResponse (toMsg << toResult)


type Expect msg
    = ExpectWhatever (Result Http.Error () -> msg)
    | ExpectBytesResponse (Response Bytes -> msg)
    | ExpectStringResponse (Response String -> msg)


expectWhatever : (Result Http.Error () -> msg) -> Expect msg
expectWhatever toMsg =
    ExpectWhatever toMsg


expectString : (Result Http.Error String -> msg) -> Expect msg
expectString toMsg =
    ExpectStringResponse (toHttpResult >> toMsg)


expectJson : (Result Http.Error value -> msg) -> Json.Decode.Decoder value -> Expect msg
expectJson toMsg decoder =
    ExpectStringResponse
        (toHttpResult
            >> Result.andThen
                (Json.Decode.decodeString decoder
                    >> Result.mapError (Json.Decode.errorToString >> Http.BadBody)
                )
            >> toMsg
        )


expectBytes : (Result Http.Error value -> msg) -> Bytes.Decode.Decoder value -> Expect msg
expectBytes toMsg decoder =
    ExpectBytesResponse
        (toHttpResult
            >> Result.andThen
                (Bytes.Decode.decode decoder
                    >> Result.fromMaybe "Unexpected bytes"
                    >> Result.mapError Http.BadBody
                )
            >> toMsg
        )


mapExpect : (msg1 -> msg2) -> Expect msg1 -> Expect msg2
mapExpect fn expect =
    case expect of
        ExpectWhatever toMsg ->
            ExpectWhatever (toMsg >> fn)

        ExpectBytesResponse toMsg ->
            ExpectBytesResponse (toMsg >> fn)

        ExpectStringResponse toMsg ->
            ExpectStringResponse (toMsg >> fn)


toHttpExpect : Expect msg -> Http.Expect msg
toHttpExpect expect =
    case expect of
        ExpectWhatever toMsg ->
            Http.expectWhatever toMsg

        ExpectBytesResponse toMsg ->
            Http.expectBytesResponse
                (\\res ->
                    case res of
                        Ok response ->
                            toMsg response

                        Err response ->
                            toMsg response
                )
                Ok

        ExpectStringResponse toMsg ->
            Http.expectStringResponse
                (\\res ->
                    case res of
                        Ok response ->
                            toMsg response

                        Err response ->
                            toMsg response
                )
                Ok


toHttpResult : Response body -> Result Http.Error body
toHttpResult response =
    case response of
        Http.BadUrl_ url ->
            Err (Http.BadUrl url)

        Http.Timeout_ ->
            Err Http.Timeout

        Http.NetworkError_ ->
            Err Http.NetworkError

        Http.BadStatus_ meta _ ->
            Err (Http.BadStatus meta.statusCode)

        Http.GoodStatus_ meta body ->
            Ok body
`.trimStart()

/**
 * 
 * @param {import(".").Options} options
 * @returns {string}
 */
const ElmLandProgram = ({ router }) =>
    router === 'markdown'
        ? ElmLandProgram_Markdown
        : ElmLandProgram_FileBased

const ElmLandEffect = () => `
-- 📦 Standard module for https://elm.land 🌈 --


module ElmLand.Effect exposing
    ( Effect
    , none, batch, map
    , custom, broadcast
    , sendMsg, sendMsgAfterDelay
    , request
    , pushUrl, replaceUrl, back, forward, load, reload, reloadAndSkipCache
    , focus, blur, getViewport, getViewportOf, setViewport, setViewportOf, getElement
    , handle
    )

{-| A helper module for defining your own "Effect" module. Comes
with functions for all the "Cmd msg" functions defined in "elm/\\*" packages.

@docs Effect
@docs none, batch, map
@docs custom, broadcast
@docs sendMsg, sendMsgAfterDelay
@docs request
@docs pushUrl, replaceUrl, back, forward, load, reload, reloadAndSkipCache
@docs focus, blur, getViewport, getViewportOf, setViewport, setViewportOf, getElement


### Used internally by Elm Land to convert Effects into messages

@docs handle

-}

import Browser.Dom
import Browser.Navigation
import ElmLand.Http
import ElmLand.Subscription
import Process
import Task
import Url exposing (Url)


{-| A generic version of your Effect type.

    -- Example usage in "src/Effect.elm"
    type alias Effect msg =
        ElmLand.Effect.Effect
            Subscription.Event
            (CustomEffect msg)
            msg

-}
type Effect event custom msg
    = -- Core
      -- https://package.elm-lang.org/packages/elm/core/latest/Platform-Cmd
      None
    | Batch (List (Effect event custom msg))
      -- Http
      -- https://package.elm-lang.org/packages/elm/http/latest/Http
    | Http (ElmLand.Http.Request msg)
      -- Browser.Navigation
      -- https://package.elm-lang.org/packages/elm/browser/latest/Browser-Navigation
    | PushUrl String
    | ReplaceUrl String
    | Back Int
    | Forward Int
    | Load String
    | Reload
    | ReloadAndSkipCache
      -- Browser.Dom
      -- https://package.elm-lang.org/packages/elm/browser/latest/Browser-Dom
    | Focus String (Result () () -> msg)
    | Blur String (Result () () -> msg)
    | GetViewport (Result () Browser.Dom.Viewport -> msg)
    | GetViewportOf String (Result () Browser.Dom.Viewport -> msg)
    | SetViewport Float Float msg
    | SetViewportOf String Float Float (Result () () -> msg)
    | GetElement String (Result () Browser.Dom.Element -> msg)
      -- Elm Land helpers
    | SendMsg msg
    | SendMsgAfterDelay Float msg
      -- User-defined
    | Broadcast event
    | Custom custom


none : Effect event c msg
none =
    None


batch : List (Effect event c msg) -> Effect event c msg
batch =
    Batch


sendMsg : msg -> Effect event c msg
sendMsg =
    SendMsg


sendMsgAfterDelay : Float -> msg -> Effect event c msg
sendMsgAfterDelay =
    SendMsgAfterDelay


custom : custom -> Effect event custom msg
custom =
    Custom


broadcast : event -> Effect event c msg
broadcast =
    Broadcast


request : ElmLand.Http.Request msg -> Effect event c msg
request =
    Http


pushUrl : String -> Effect event c msg
pushUrl =
    PushUrl


replaceUrl : String -> Effect event c msg
replaceUrl =
    ReplaceUrl


back : Int -> Effect event c msg
back =
    Back


forward : Int -> Effect event c msg
forward =
    Forward


load : String -> Effect event c msg
load =
    Load


reload : Effect event c msg
reload =
    Reload


reloadAndSkipCache : Effect event c msg
reloadAndSkipCache =
    ReloadAndSkipCache


blur : String -> (Result () () -> msg) -> Effect event c msg
blur =
    Blur


focus : String -> (Result () () -> msg) -> Effect event c msg
focus =
    Focus


getViewport : (Result () Browser.Dom.Viewport -> msg) -> Effect event c msg
getViewport =
    GetViewport


getViewportOf : String -> (Result () Browser.Dom.Viewport -> msg) -> Effect event c msg
getViewportOf =
    GetViewportOf


setViewport : Float -> Float -> msg -> Effect event c msg
setViewport =
    SetViewport


setViewportOf : String -> Float -> Float -> (Result () () -> msg) -> Effect event c msg
setViewportOf =
    SetViewportOf


getElement : String -> (Result () Browser.Dom.Element -> msg) -> Effect event c msg
getElement =
    GetElement


map : (custom1 -> custom2) -> (msg1 -> msg2) -> Effect event custom1 msg1 -> Effect event custom2 msg2
map fnCustom fn effect =
    case effect of
        None ->
            None

        Batch list ->
            Batch (List.map (map fnCustom fn) list)

        SendMsg msg ->
            SendMsg (fn msg)

        SendMsgAfterDelay delay msg ->
            SendMsgAfterDelay delay (fn msg)

        Http req ->
            Http (ElmLand.Http.map fn req)

        PushUrl string ->
            PushUrl string

        ReplaceUrl string ->
            ReplaceUrl string

        Back amount ->
            Back amount

        Forward amount ->
            Forward amount

        Load url ->
            Load url

        Reload ->
            Reload

        ReloadAndSkipCache ->
            ReloadAndSkipCache

        Focus id toMsg ->
            Focus id (toMsg >> fn)

        Blur id toMsg ->
            Blur id (toMsg >> fn)

        GetViewport toMsg ->
            GetViewport (toMsg >> fn)

        GetViewportOf id toMsg ->
            GetViewportOf id (toMsg >> fn)

        SetViewport x y msg ->
            SetViewport x y (msg |> fn)

        SetViewportOf id x y toMsg ->
            SetViewportOf id x y (toMsg >> fn)

        GetElement id toMsg ->
            GetElement id (toMsg >> fn)

        Broadcast event ->
            Broadcast event

        Custom customEffect ->
            Custom (fnCustom customEffect)


handle :
    (custom -> Url -> Browser.Navigation.Key -> shared -> ( shared, Cmd msg ))
    -> (listener -> event -> List msg)
    -> listener
    -> Effect event custom msg
    -> Url
    -> Browser.Navigation.Key
    -> shared
    -> ( shared, Cmd msg )
handle toCustomEffect onEvent listener effect url key shared =
    case effect of
        None ->
            ( shared, Cmd.none )

        Batch children ->
            let
                fold : Effect event custom msg -> ( shared, List (Cmd msg) ) -> ( shared, List (Cmd msg) )
                fold childEffect ( innerShared, cmds ) =
                    handle toCustomEffect onEvent listener childEffect url key innerShared
                        |> Tuple.mapSecond (List.singleton >> List.append cmds)
            in
            children
                |> List.foldl fold ( shared, [] )
                |> Tuple.mapSecond Cmd.batch

        SendMsg msg ->
            ( shared
            , Task.succeed msg
                |> Task.perform identity
            )

        SendMsgAfterDelay delay msg ->
            ( shared
            , Process.sleep delay
                |> Task.perform (always msg)
            )

        Http req ->
            ( shared, ElmLand.Http.toCmd req )

        PushUrl newUrl ->
            ( shared, Browser.Navigation.pushUrl key newUrl )

        ReplaceUrl newUrl ->
            ( shared, Browser.Navigation.replaceUrl key newUrl )

        Back n ->
            ( shared, Browser.Navigation.back key n )

        Forward n ->
            ( shared, Browser.Navigation.forward key n )

        Load newUrl ->
            ( shared, Browser.Navigation.load newUrl )

        Reload ->
            ( shared, Browser.Navigation.reload )

        ReloadAndSkipCache ->
            ( shared, Browser.Navigation.reloadAndSkipCache )

        Focus id toMsg ->
            ( shared, Browser.Dom.focus id |> Task.mapError (always ()) |> Task.attempt toMsg )

        Blur id toMsg ->
            ( shared, Browser.Dom.blur id |> Task.mapError (always ()) |> Task.attempt toMsg )

        GetViewport toMsg ->
            ( shared, Browser.Dom.getViewport |> Task.attempt toMsg )

        GetViewportOf id toMsg ->
            ( shared, Browser.Dom.getViewportOf id |> Task.mapError (always ()) |> Task.attempt toMsg )

        SetViewport x y msg ->
            ( shared, Browser.Dom.setViewport x y |> Task.perform (always msg) )

        SetViewportOf id x y toMsg ->
            ( shared, Browser.Dom.setViewportOf id x y |> Task.mapError (always ()) |> Task.attempt toMsg )

        GetElement id toMsg ->
            ( shared, Browser.Dom.getElement id |> Task.mapError (always ()) |> Task.attempt toMsg )

        Broadcast event ->
            ( shared
            , onEvent listener event
                |> List.map (Task.perform identity << Task.succeed)
                |> Cmd.batch
            )

        Custom customEffect ->
            toCustomEffect customEffect url key shared
`.trimStart()

const ElmLandSubscription = () => `
-- 📦 Standard module for https://elm.land 🌈 --


module ElmLand.Subscription exposing
    ( Subscription
    , none, batch
    , map
    , onAnimationFrame, onAnimationFrameDelta
    , onClick, onKeyDown, onKeyPress, onKeyUp
    , onMouseDown, onMouseMove, onMouseUp
    , onResize, onVisibilityChange
    , custom
    , Handler, handleEvent, handleSub
    , toSub, toMsgs
    )

{-| A helper module for defining your own "Subscription" module. Comes
with functions for all the "Sub msg" functions defined in "elm/\\*" packages.

@docs Subscription


### elm/core

@docs none, batch
@docs map


### elm/browser

@docs onAnimationFrame, onAnimationFrameDelta
@docs onClick, onKeyDown, onKeyPress, onKeyUp
@docs onMouseDown, onMouseMove, onMouseUp
@docs onResize, onVisibilityChange


### Custom subscriptions

@docs custom
@docs Handler, handleEvent, handleSub
@docs toSub, toMsgs

-}

import Browser.Events
import Json.Decode as Json
import Time


{-| Represents a subscription for an event from the browser or somewhere else in
the application.
-}
type Subscription custom msg
    = -- elm/core
      None
    | Batch (List (Subscription custom msg))
      -- elm/browser
    | OnAnimationFrame (Time.Posix -> msg)
    | OnAnimationFrameDelta (Float -> msg)
    | OnKeyDown (Json.Decoder msg)
    | OnKeyPress (Json.Decoder msg)
    | OnKeyUp (Json.Decoder msg)
    | OnClick (Json.Decoder msg)
    | OnMouseDown (Json.Decoder msg)
    | OnMouseMove (Json.Decoder msg)
    | OnMouseUp (Json.Decoder msg)
    | OnVisibilityChange (Browser.Events.Visibility -> msg)
    | OnResize (Int -> Int -> msg)
      -- CUSTOM
    | Custom custom


{-| Don't subscribe to any events.
-}
none : Subscription c msg
none =
    None


{-| Subscribe to multiple events at once
-}
batch : List (Subscription c msg) -> Subscription c msg
batch =
    Batch


{-| See "Browser.Events.onResize"
-}
onResize : (Int -> Int -> msg) -> Subscription c msg
onResize =
    OnResize


{-| See "Browser.Events.onAnimationFrame"
-}
onAnimationFrame : (Time.Posix -> msg) -> Subscription c msg
onAnimationFrame =
    OnAnimationFrame


{-| See "Browser.Events.onAnimationFrameDelta"
-}
onAnimationFrameDelta : (Float -> msg) -> Subscription c msg
onAnimationFrameDelta =
    OnAnimationFrameDelta


{-| See "Browser.Events.onKeyDown"
-}
onKeyDown : Json.Decoder msg -> Subscription c msg
onKeyDown =
    OnKeyDown


{-| See "Browser.Events.onKeyPress"
-}
onKeyPress : Json.Decoder msg -> Subscription c msg
onKeyPress =
    OnKeyPress


{-| See "Browser.Events.onKeyUp"
-}
onKeyUp : Json.Decoder msg -> Subscription c msg
onKeyUp =
    OnKeyUp


{-| See "Browser.Events.onClick"
-}
onClick : Json.Decoder msg -> Subscription c msg
onClick =
    OnClick


{-| See "Browser.Events.onMouseDown"
-}
onMouseDown : Json.Decoder msg -> Subscription c msg
onMouseDown =
    OnMouseDown


{-| See "Browser.Events.onMouseMove"
-}
onMouseMove : Json.Decoder msg -> Subscription c msg
onMouseMove =
    OnMouseMove


{-| See "Browser.Events.onMouseUp"
-}
onMouseUp : Json.Decoder msg -> Subscription c msg
onMouseUp =
    OnMouseUp


{-| See "Browser.Events.onVisibilityChange"
-}
onVisibilityChange : (Browser.Events.Visibility -> msg) -> Subscription c msg
onVisibilityChange =
    OnVisibilityChange


{-| Define a custom subscription that can be triggered
using "Effect.broadcast"
-}
custom : custom -> Subscription custom msg
custom =
    Custom


{-| Convert a Subscription to use a different kind of message.
-}
map :
    (custom1 -> custom2)
    -> (msg1 -> msg2)
    -> Subscription custom1 msg1
    -> Subscription custom2 msg2
map fnCustom fnMsg sub =
    case sub of
        None ->
            None

        Batch list ->
            Batch (List.map (map fnCustom fnMsg) list)

        OnResize handler ->
            OnResize (\\w h -> fnMsg (handler w h))

        OnAnimationFrame handler ->
            OnAnimationFrame (handler >> fnMsg)

        OnAnimationFrameDelta handler ->
            OnAnimationFrameDelta (handler >> fnMsg)

        OnKeyDown decoder ->
            OnKeyDown (Json.map fnMsg decoder)

        OnKeyPress decoder ->
            OnKeyPress (Json.map fnMsg decoder)

        OnKeyUp decoder ->
            OnKeyUp (Json.map fnMsg decoder)

        OnClick decoder ->
            OnClick (Json.map fnMsg decoder)

        OnMouseDown decoder ->
            OnMouseDown (Json.map fnMsg decoder)

        OnMouseMove decoder ->
            OnMouseMove (Json.map fnMsg decoder)

        OnMouseUp decoder ->
            OnMouseUp (Json.map fnMsg decoder)

        OnVisibilityChange handler ->
            OnVisibilityChange (handler >> fnMsg)

        Custom c ->
            Custom (fnCustom c)


{-| Helper for converting a listener into subscriptions.
-}
toSub :
    (c -> Handler event msg)
    -> Subscription c msg
    -> Sub msg
toSub handleCustom listener =
    toHandler handleCustom listener
        |> fromHandlerToSub


{-| Helper for converting a listener into subscriptions.
-}
toMsgs :
    (c -> Handler event msg)
    -> Subscription c msg
    -> event
    -> List msg
toMsgs handleCustom listener event =
    toHandler handleCustom listener
        |> fromHandlerToMsgs event



-- HANDLER


type Handler event msg
    = HandleSub (Sub msg)
    | HandleEvent (event -> Maybe msg)
    | HandleBatch (List (Handler event msg))


handleEvent : (event -> Maybe msg) -> Handler event msg
handleEvent =
    HandleEvent


handleSub : Sub msg -> Handler event msg
handleSub =
    HandleSub


toHandler : (c -> Handler event msg) -> Subscription c msg -> Handler event msg
toHandler handleCustom listener =
    case listener of
        None ->
            HandleSub <| Sub.none

        Batch children ->
            HandleBatch (List.map (toHandler handleCustom) children)

        OnResize handler ->
            HandleSub <| Browser.Events.onResize handler

        OnAnimationFrame handler ->
            HandleSub <| Browser.Events.onAnimationFrame handler

        OnAnimationFrameDelta handler ->
            HandleSub <| Browser.Events.onAnimationFrameDelta handler

        OnKeyDown handler ->
            HandleSub <| Browser.Events.onKeyDown handler

        OnKeyPress handler ->
            HandleSub <| Browser.Events.onKeyPress handler

        OnKeyUp handler ->
            HandleSub <| Browser.Events.onKeyUp handler

        OnClick handler ->
            HandleSub <| Browser.Events.onClick handler

        OnMouseDown handler ->
            HandleSub <| Browser.Events.onMouseDown handler

        OnMouseMove handler ->
            HandleSub <| Browser.Events.onMouseMove handler

        OnMouseUp handler ->
            HandleSub <| Browser.Events.onMouseUp handler

        OnVisibilityChange handler ->
            HandleSub <| Browser.Events.onVisibilityChange handler

        Custom c ->
            handleCustom c


fromHandlerToSub : Handler event msg -> Sub msg
fromHandlerToSub handler =
    case handler of
        HandleSub sub ->
            sub

        HandleEvent _ ->
            Sub.none

        HandleBatch inner ->
            Sub.batch (List.map fromHandlerToSub inner)


fromHandlerToMsgs : event -> Handler event msg -> List msg
fromHandlerToMsgs event handler =
    case handler of
        HandleSub sub ->
            []

        HandleEvent fn ->
            case fn event of
                Just msg ->
                    [ msg ]

                Nothing ->
                    []

        HandleBatch inner ->
            List.concatMap (fromHandlerToMsgs event) inner
`.trimStart()

// SPA/MPA OUTPUT

const ElmLandMeta = () => `
-- 📦 Standard module for https://elm.land 🌈 --


module ElmLand.Meta exposing
    ( Meta, html
    , HtmlTag
    , title, description
    , link, script, style, meta, noscript
    , none, batch, optional, crash
    , Context
    , encode
    )

{-|

@docs Meta, html

@docs HtmlTag

@docs title, description
@docs link, script, style, meta, noscript

@docs none, batch, optional, crash


## Build time info

@docs Context
@docs env, now


## Used by Elm Land internally

@docs encode

-}

import Dict exposing (Dict)
import Json.Encode as Encode
import Set exposing (Set)
import Time



-- META


{-| A collection of HTML tags to be rendered in the HTML
sent with the page before JavaScript runs in the browser.

    Meta.html [ ( "language", "en" ) ]
        |> Meta.title "My cool app"
        |> Meta.description "Welcome to my site!"
    --
    -- Emits:
    --
    -- <html language="en">
    -- <head>
    --   <title>My cool app</title>
    --   <meta name="description" content="Welcome to my site!">
    -- </head>
    -- <body>...</body>
    --

-}
type Meta
    = Meta MetaInfo


html : List ( String, String ) -> List HtmlTag -> Meta
html attributes_ tags =
    Meta
        { html = attributes_
        , tags = tags
        }



-- CONTEXT


{-| Context provided by Elm Land at build time.

This provides access to environment variables and
the current time.

    meta : Meta.Context -> Meta
    meta { env, now } =
        Meta.html [ ( "lang", "en" ) ]
            |> Meta.title "My cool app"
            |> Meta.meta
                [ ( "property", "og:url" )
                , ( "content", env "APP_URL" )
                ]

-}
type alias Context =
    { env : String -> Maybe String
    , now : Time.Posix
    }



-- META TAGS


{-| Renders a <title> tag.

    -- <title>My cool app</title>
    title "My cool app"

-}
title : String -> HtmlTag
title title_ =
    HtmlTag (Tag "title" [] (HasClosingTagWithContent title_))


{-| Renders a <meta> tag with a description.

    -- <meta name="description" content="Welcome to my site!">
    description "Welcome to my site!"

-}
description : String -> HtmlTag
description description_ =
    HtmlTag
        (Tag
            "meta"
            [ ( "name", "description" )
            , ( "content", description_ )
            ]
            SelfClosing
        )


{-| Renders a <link> tag.

    -- <link rel="stylesheet" href="style.css"></link>
    link [ ( "rel", "stylesheet" ), ( "href", "style.css" ) ]

-}
link : List ( String, String ) -> HtmlTag
link attributes_ =
    HtmlTag (Tag "link" attributes_ HasClosingTag)


{-| Renders a <meta> tag.

    -- <meta name="description" content="Welcome to my site!">
    meta [ ( "charset", "utf-8" ) ]

    -- <meta property="og:image" content="https://example.com/image.jpg">
    meta [ ( "property", "og:image" ), ( "content", "https://example.com/image.jpg" ) ]

-}
meta : List ( String, String ) -> HtmlTag
meta attributes_ =
    HtmlTag (Tag "meta" attributes_ SelfClosing)


{-| Renders a <style> tag.

    -- <style>body { font-family: sans-serif; }</style>
    style "body { font-family: sans-serif; }"

-}
style : String -> HtmlTag
style content_ =
    HtmlTag (Tag "style" [] (HasClosingTagWithContent content_))


{-| Renders a <script> tag.

    -- <script type="application/javascript" src="/jquery.js"></script>
    script [ ( "type", "application/javascript" ), ( "src", "/jquery.js" ) ] Nothing

    -- <script>console.log('Hello, world!');</script>
    script [] (Just "console.log('Hello, world!');")

-}
script : List ( String, String ) -> Maybe String -> HtmlTag
script attributes_ maybeContent_ =
    HtmlTag
        (Tag "script"
            attributes_
            (case maybeContent_ of
                Just content_ ->
                    HasClosingTagWithContent content_

                Nothing ->
                    HasClosingTag
            )
        )


{-| Renders a <noscript> tag. This renders a fallback for browsers that
do not support JavaScript or have it disabled.

    -- <noscript>This website relies on JavaScript to create a great experience.</noscript>
    noscript "This website relies on JavaScript to create a great experience."

-}
noscript : String -> HtmlTag
noscript content_ =
    NoScript content_


{-| Helpful for conditionals where you don't want to render a tag at all
-}
none : HtmlTag
none =
    None


{-| Helpful for conditionally rendering a group of tags

    meta : Meta.Context -> Meta
    meta { env, now } =
        Meta.html [ ( "lang", "en" ) ]
            [ Meta.title "My cool app"
            , case env "APP_URL" of
                Just appUrl ->
                    Meta.batch
                        [ Meta.meta [ ( "property", "og:title" ), ( "content", "My cool app" ) ]
                        , Meta.meta [ ( "property", "og:url" ), ( "content", appUrl ) ]
                        ]

                Nothing ->
                    Meta.crash "Missing APP_URL env variable"
            ]

-}
batch : List HtmlTag -> HtmlTag
batch =
    Batch


{-| A helper for working with "Maybe" values
-}
optional : (value -> HtmlTag) -> Maybe value -> HtmlTag
optional toTag maybe =
    case maybe of
        Just value ->
            toTag value

        Nothing ->
            none


{-| If a build time value is not what you expect, you can opt to crash
the build process and report the provided error in your logs.
-}
crash : String -> HtmlTag
crash =
    Crash



-- INTERNALS


type HtmlTag
    = HtmlTag Tag
    | None
    | NoScript String
    | Crash String
    | Batch (List HtmlTag)


type alias Tag =
    { name : String
    , attributes : List Attribute
    , content : HtmlContent
    }


type HtmlContent
    = SelfClosing
    | HasClosingTag
    | HasClosingTagWithContent String


type alias Attribute =
    ( String, String )



-- NEEDED BY ELM LAND


{-| Encode a Meta value to a JSON value that can be rendered in
the head of an HTML page.

-- If it worked:

    {
        "html": { "language": "en" },
        "head": [
            { "name": "title", attributes: {}, content: "My cool-app" },
            { "name": "meta", attributes: { "charset": "utf-8" } }
        ],
        "noscript": null
    }

-- If it failed:

    {
        "error": "Expected the APP_URL environment variable!"
    }

-}
encode : Meta -> Encode.Value
encode (Meta info) =
    let
        loop : HtmlTag -> EncodeState -> EncodeState
        loop htmlTag state =
            case htmlTag of
                None ->
                    state

                HtmlTag tag ->
                    { state | head = tag :: state.head }

                Crash reason ->
                    { state | crash = Just reason }

                NoScript string ->
                    if state.noScript == Nothing then
                        { state | noScript = state.noScript |> Maybe.withDefault string |> Just }

                    else
                        state

                Batch inner ->
                    List.foldr loop state inner

        final : EncodeState
        final =
            info.tags
                |> List.foldr loop
                    { crash = Nothing
                    , noScript = Nothing
                    , head = []
                    }
    in
    case final.crash of
        Just reason ->
            Encode.object
                [ ( "error", Encode.string reason )
                ]

        Nothing ->
            Encode.object
                [ ( "html", toJsonAttribute info.html )
                , ( "head", Encode.list toJsonTag final.head )
                , ( "noScript"
                  , case final.noScript of
                        Nothing ->
                            Encode.null

                        Just str ->
                            Encode.string str
                  )
                ]


type alias EncodeState =
    { crash : Maybe String
    , head : List Tag
    , noScript : Maybe String
    }



-- INTERNALS


type alias MetaInfo =
    { html : List ( String, String )
    , tags : List HtmlTag
    }


toJsonTag : Tag -> Encode.Value
toJsonTag tag_ =
    Encode.object
        [ ( "name", Encode.string tag_.name )
        , ( "attributes", toJsonAttribute tag_.attributes )
        , ( "content", toJsonContent tag_.content )
        ]


toJsonAttribute : List ( String, String ) -> Encode.Value
toJsonAttribute list =
    Encode.object (List.map (Tuple.mapSecond Encode.string) list)


toJsonContent : HtmlContent -> Encode.Value
toJsonContent content_ =
    case content_ of
        SelfClosing ->
            Encode.null

        HasClosingTag ->
            Encode.string ""

        HasClosingTagWithContent content ->
            Encode.string content
`.trimStart()

// MARKDOWN ROUTER

const ElmLandContent = () => `
-- 📦 Standard module for https://elm.land 🌈 --


module ElmLand.Content exposing
    ( Decoder, new
    , map
    , withMarkdownBody
    , withRequiredField, withOptionalField
    , withUrl
    , withFile, withFilesInFolder, withFilesInFolderRecursive
    , minify, decode
    , FilesNeeded, toFilesNeeded, isReferenced
    )

{-| Describe the data you expect for a given page


## Decoders

@docs Decoder, new
@docs map


### Frontmatter & Markdown

@docs withMarkdownBody
@docs withRequiredField, withOptionalField
@docs withUrl


### Related files

@docs withFile, withFilesInFolder, withFilesInFolderRecursive


### Internals

@docs minify, decode
@docs FilesNeeded, toFilesNeeded, isReferenced

-}

import ElmLand.File as File
import ElmLand.Frontmatter as Frontmatter
import Json.Decode
import Json.Decode.Exploration as Json
import Json.Decode.Exploration.Located as Located exposing (Located)
import Json.Encode
import List.Nonempty



-- DECODERS


{-| A value that describes what content your page expects.

This prevents your website from crashing if you have a typo in your frontmatter.

-}
type Decoder value
    = Decoder
        { toDecoder : DecoderWithFilepaths value
        , folders : List Folder
        , files : List String
        }


type alias Filepath =
    String



-- Helper for decoders that need context
-- to properly dead-json eliminate


type alias DecoderWithFilepaths value =
    List Filepath -> Json.Decoder value


with :
    DecoderWithFilepaths field
    -> DecoderWithFilepaths (field -> output)
    -> DecoderWithFilepaths output
with toFieldDecoder toExistingDecoder filepaths =
    Json.map2 (|>)
        (toFieldDecoder filepaths)
        (toExistingDecoder filepaths)


mapJsonDecoder : (a -> b) -> DecoderWithFilepaths a -> DecoderWithFilepaths b
mapJsonDecoder fn toDecoderA filepaths =
    toDecoderA filepaths
        |> Json.map fn


{-| Map from one decoder to another
-}
map : (a -> b) -> Decoder a -> Decoder b
map fn (Decoder record) =
    Decoder
        { toDecoder = mapJsonDecoder fn record.toDecoder
        , folders = record.folders
        , files = record.files
        }


{-| Tells Elm Land what folders to request at build time.

This is useful for allowing the "/blog" route to request content
from the "blog" folder at build time.

-}
type alias Folder =
    { path : String
    , isRecursive : Bool
    }


{-| Create a new decoder for your content that always succeeds.

Is mainly used to build up a record type alias like "Content" with
all the content and information you need.

    type alias Content =
        { title : String
        , description : Maybe String
        , markdown : String
        }

    content : Decoder Content
    content =
        new Content
            |> withRequired "title"
            |> withOptional "description"
            |> withMarkdown

-}
new : value -> Decoder value
new value =
    Decoder
        { toDecoder = \\_ -> Json.succeed value
        , folders = []
        , files = []
        }



-- MODIFIERS


{-| Get a frontmatter field that is required.

If the field is not found, the decoder will fail, and you will
receive a helpful error message during development (or a build error
to prevent you from deploying a broken site).

-}
withRequiredField : String -> Frontmatter.Decoder value -> Decoder (value -> output) -> Decoder output
withRequiredField name fmDecoder (Decoder fn) =
    Decoder
        { toDecoder =
            fn.toDecoder
                |> with (\\_ -> Json.at [ "frontmatter", name ] (Frontmatter.toJsonDecoder fmDecoder))
        , folders = fn.folders
        , files = fn.files
        }


{-| Get a frontmatter field that is optional.

If the field is not found, or it doesn't match the expected type,
the decoder will succeed with a "Nothing" value.

Use this for fields that might be missing, or cannot be trusted to
always be present with the same shape.

-}
withOptionalField : String -> Frontmatter.Decoder value -> Decoder (Maybe value -> output) -> Decoder output
withOptionalField name fmDecoder (Decoder fn) =
    Decoder
        { toDecoder =
            fn.toDecoder
                |> with (\\_ -> Json.maybe (Json.at [ "frontmatter", name ] (Frontmatter.toJsonDecoder fmDecoder)))
        , folders = fn.folders
        , files = fn.files
        }


{-| Include the URL of the content.

The current URL is already available via the "route" value,
but this is useful for nested pages that need to link from
the current page.

Imagine rendering all your blog posts on the "/blog" page,
you will need to know the URL for each blog post to link to it.

See "withAllFilesUnder" to learn how to request all files
under a given URL path.

-}
withUrl : Decoder (String -> output) -> Decoder output
withUrl (Decoder existing) =
    Decoder
        { toDecoder =
            existing.toDecoder
                |> with (\\_ -> Json.field "url" Json.string)
        , folders = existing.folders
        , files = existing.files
        }


{-| Include the markdown content of the file.

This is useful for pages that want to render the markdown
content as HTML in the browser.

-}
withMarkdownBody : Decoder (String -> output) -> Decoder output
withMarkdownBody (Decoder existing) =
    Decoder
        { toDecoder =
            existing.toDecoder
                |> with (\\_ -> Json.field "markdown" Json.string)
        , folders = existing.folders
        , files = existing.files
        }


{-| Include content for a single file.
-}
withFile : String -> File.Decoder file -> Decoder (file -> output) -> Decoder output
withFile filepath fileDecoder (Decoder existing) =
    let
        toFileDecoder : List Filepath -> Json.Decoder file
        toFileDecoder _ =
            Json.at [ "content", filepath ]
                (File.toJsonDecoder fileDecoder)
    in
    Decoder
        { toDecoder =
            existing.toDecoder
                |> with toFileDecoder
        , folders = existing.folders
        , files = filepath :: existing.files
        }


{-| Include all files directly within a given folder.

Example: "withFilesInFolder "/blog" ..."

  - "/blog/123" ✅
  - "/blog/456" ✅
  - "/blog/topic/123" ❌
  - "/settings" ❌

This is useful for allowing the "/blog" route to request content
from the "blog" folder at build time.

**Note:** You can not use this within nested decoders– this only
works on the top level Content.Decoder.

-}
withFilesInFolder : String -> File.Decoder file -> Decoder (List file -> output) -> Decoder output
withFilesInFolder folder fileDecoder (Decoder existing) =
    Decoder
        { toDecoder =
            existing.toDecoder
                |> with (toWithFilesInFolder isDirectChildOf folder fileDecoder)
        , folders = { path = folder, isRecursive = False } :: existing.folders
        , files = existing.files
        }


{-| Same as "withFilesInFolder", but finds files in nested folders:

Example: "withFilesInFolder "/blog" ..."

  - "/blog/123" ✅
  - "/blog/456" ✅
  - "/blog/topic/123" ✅
  - "/settings" ❌

-}
withFilesInFolderRecursive : String -> File.Decoder file -> Decoder (List file -> output) -> Decoder output
withFilesInFolderRecursive folder fileDecoder (Decoder existing) =
    Decoder
        { toDecoder =
            existing.toDecoder
                |> with (toWithFilesInFolder isDescendantOf folder fileDecoder)
        , folders = { path = folder, isRecursive = True } :: existing.folders
        , files = existing.files
        }



-- INTERNALS


{-| Strip down the JSON value to only include the fields
required by the decoder.

This is useful for reducing the size of the JSON included
in your initial HTML file and fetched during page navigation.

Note: If the provided JSON doesn't work with the decoder, you will get an
error as if you ran the "decode" function

-}
minify :
    Decoder value
    -> Json.Value
    -> Result Json.Decode.Error ( value, Json.Value )
minify (Decoder record) json =
    let
        filepaths : List Filepath
        filepaths =
            toFilepathsFromJson json
    in
    Result.map2 Tuple.pair
        (decode (Decoder record) json)
        (json
            |> Json.stripValue (record.toDecoder filepaths)
            |> Result.mapError fromErrorsToError
        )


{-| Run the decoder on a JSON value.

This is useful for decoding content from a JSON file.

The expected JSON structure is:

    {
        "url": "/",
        "markdown": "..."
        "frontmatter": {
            "title": "Homepage",
            ...
        },
        "content": {
            "blog/123.md": {
                "url": "/blog/123",
                "markdown": "...",
                "frontmatter": { ... }
            },
            "blog/456.md": {
                "url": "/blog/456",
                "markdown": "...",
                "frontmatter": { ... }
            },
            "numbers.json": "[ 1, 2, 3 ]"
        }
    }

For performance reasons, Elm Land breaks getting content into three steps:

1.  For a given page, Elm Land will ask the page's "decoder" what files and folders should be loaded
    from the filesystem.
2.  Elm Land loads only those files and provides things in the JSON format shown above, along with all
    content folder filepaths that were accessed from the file system.
3.  This allows Elm Land to call this "decode" function with those filepaths and the JSON to test if the file system
    passes the decoding test.
      - If the decoder passes, we use the "minify" function to get the subset of JSON needed to get the page's initial Data
      - If the decoder fails, we send an error during "elm-land server" and fail the build during "elm-land make"

-}
decode : Decoder value -> Json.Value -> Result Json.Decode.Error value
decode (Decoder record) json =
    json
        |> Json.decodeValue (record.toDecoder (toFilepathsFromJson json))
        |> toResult


toFilepathsFromJson : Json.Value -> List Filepath
toFilepathsFromJson json =
    Json.decodeValue
        (Json.field "content"
            (Json.keyValuePairs (Json.succeed ()))
            |> Json.map (List.map Tuple.first)
        )
        json
        |> toResult
        |> Result.withDefault []


toResult : Json.DecodeResult value -> Result Json.Decode.Error value
toResult jsonDecodeResult =
    case jsonDecodeResult of
        Json.BadJson ->
            Err (Json.Decode.Failure "Expected a JSON value" Json.Encode.null)

        Json.Errors errors ->
            Err (fromErrorsToError errors)

        Json.WithWarnings _ value ->
            Ok value

        Json.Success value ->
            Ok value


{-| Return the list of folders required to decode the
content.

This allows the "/blog" route to request content
from the "blog" folder at build time.

-}
folders : Decoder value -> List Folder
folders (Decoder record) =
    record.folders



-- FILES NEEDED


type alias FilesNeeded =
    { files : List Filepath
    , folders : List { path : Filepath, isRecursive : Bool }
    }


{-| Tells Elm Land's build process which files to read from disk
-}
toFilesNeeded : Decoder value -> FilesNeeded
toFilesNeeded (Decoder record) =
    FilesNeeded
        record.files
        record.folders


{-| Let's Elm Land know if a markdown filepath is referenced by this decoder.
-}
isReferenced : Filepath -> Decoder value -> Bool
isReferenced target (Decoder record) =
    let
        isReferencedInFolderSearch : { path : Filepath, isRecursive : Bool } -> Bool
        isReferencedInFolderSearch { path, isRecursive } =
            if isRecursive then
                isDescendantOf path target

            else
                isDirectChildOf path target
    in
    List.member target record.files
        || List.any isReferencedInFolderSearch record.folders



-- JSON EXTRA


combine : List (Json.Decoder a) -> Json.Decoder (List a)
combine decoders =
    List.foldr
        (Json.map2 (::))
        (Json.succeed [])
        decoders


isDirectChildOf : Filepath -> Filepath -> Bool
isDirectChildOf folder file =
    let
        folderParts =
            splitIntoParts folder

        fileParts =
            splitIntoParts file
    in
    if List.length fileParts == List.length folderParts + 1 then
        isDescendantOf folder file

    else
        False


isDescendantOf : Filepath -> Filepath -> Bool
isDescendantOf folder file =
    trimSurroundingSlashes file
        |> String.startsWith (trimSurroundingSlashes folder)


trimSurroundingSlashes : String -> String
trimSurroundingSlashes str =
    str
        |> String.split "/"
        |> List.filter (String.isEmpty >> not)
        |> String.join "/"


splitIntoParts : Filepath -> List String
splitIntoParts filepath =
    trimSurroundingSlashes filepath
        |> String.split "/"


toWithFilesInFolder :
    (Filepath -> Filepath -> Bool)
    -> String
    -> File.Decoder file
    -> List Filepath
    -> Json.Decoder (List file)
toWithFilesInFolder isMatch folder fileDecoder filepaths =
    let
        filesInFolder : List Filepath
        filesInFolder =
            filepaths |> List.filter (isMatch folder)

        toFileDecoder : Filepath -> Json.Decoder file
        toFileDecoder filepath =
            Json.at [ "content", filepath ] (File.toJsonDecoder fileDecoder)
    in
    filesInFolder
        |> List.map toFileDecoder
        |> combine



-- CONVERTING JSON EXPLORATION ERRORS TO JSON ERRORS


fromErrorsToError : Json.Errors -> Json.Decode.Error
fromErrorsToError errors =
    case List.Nonempty.toList errors |> List.map fromLocatedError of
        [ error ] ->
            error

        list ->
            Json.Decode.OneOf list


fromLocatedError : Located Json.Error -> Json.Decode.Error
fromLocatedError located =
    case located of
        Located.InField field inner ->
            Json.Decode.Field field (fromErrorsToError inner)

        Located.AtIndex index inner ->
            Json.Decode.Index index (fromErrorsToError inner)

        Located.Here error ->
            fromError error


fromError : Json.Error -> Json.Decode.Error
fromError error =
    case error of
        Json.BadOneOf inner ->
            Json.Decode.OneOf (List.map fromErrorsToError inner)

        Json.Expected Json.TString value ->
            Json.Decode.Failure "Expected a string" value

        Json.Expected Json.TBool value ->
            Json.Decode.Failure "Expected a boolean" value

        Json.Expected Json.TInt value ->
            Json.Decode.Failure "Expected a integer" value

        Json.Expected Json.TNumber value ->
            Json.Decode.Failure "Expected a number" value

        Json.Expected Json.TArray value ->
            Json.Decode.Failure "Expected an array" value

        Json.Expected Json.TObject value ->
            Json.Decode.Failure "Expected an object" value

        Json.Expected Json.TNull value ->
            Json.Decode.Failure "Expected a null" value

        Json.Expected (Json.TArrayIndex i) value ->
            Json.Decode.Failure ("Expected array index " ++ String.fromInt i) value

        Json.Expected (Json.TObjectField f) value ->
            Json.Decode.Failure ("Expected object field \\"" ++ f ++ "\\"") value

        Json.Failure msg (Just value) ->
            Json.Decode.Failure msg value

        Json.Failure msg Nothing ->
            Json.Decode.Failure msg Json.Encode.null
`.trimStart()

const ElmLandMarkdown = () => `
-- 📦 Standard module for https://elm.land 🌈 --


module ElmLand.Markdown exposing
    ( Decoder, new
    , withMarkdownBody, withFrontmatter
    , withRequiredField, withOptionalField
    , withUrl
    , map
    , toJsonDecoder
    )

{-| Access frontmatter and other content inside a markdown file

@docs Decoder, new
@docs withMarkdownBody, withFrontmatter
@docs withRequiredField, withOptionalField
@docs withUrl
@docs map

@docs toJsonDecoder

-}

import ElmLand.Frontmatter as Frontmatter
import Json.Decode.Exploration as Json


{-| Represents the content you want to access
-}
type Decoder value
    = Decoder (Json.Decoder value)


{-| Create a new decoder.
-}
new : value -> Decoder value
new value =
    Decoder (Json.succeed value)


with : Decoder a -> Decoder (a -> value) -> Decoder value
with (Decoder decoder) (Decoder fnDecoder) =
    Decoder (Json.map2 (|>) decoder fnDecoder)


{-| Get the markdown body for this page
-}
withMarkdownBody : Decoder (String -> value) -> Decoder value
withMarkdownBody fnDecoder =
    with (Decoder (Json.field "markdown" Json.string)) fnDecoder


{-| Get the frontmatter for this markdown file
-}
withFrontmatter :
    Frontmatter.Decoder frontmatter
    -> Decoder (frontmatter -> value)
    -> Decoder value
withFrontmatter frontmatterDecoder fnDecoder =
    with
        (Decoder
            (Json.field "frontmatter"
                (Frontmatter.toJsonDecoder frontmatterDecoder)
            )
        )
        fnDecoder


{-| Shorthand for directly accessing a required frontmatter field
-}
withRequiredField :
    String
    -> Frontmatter.Decoder field
    -> Decoder (field -> value)
    -> Decoder value
withRequiredField name frontmatterDecoder (Decoder fnDecoder) =
    Json.map2 (|>)
        (Json.at [ "frontmatter", name ] (Frontmatter.toJsonDecoder frontmatterDecoder))
        fnDecoder
        |> Decoder


{-| Shorthand for directly accessing an optional frontmatter field
-}
withOptionalField :
    String
    -> Frontmatter.Decoder field
    -> Decoder (Maybe field -> value)
    -> Decoder value
withOptionalField name frontmatterDecoder (Decoder decoder) =
    Json.map2 (|>)
        (Json.maybe (Json.at [ "frontmatter", name ] (Frontmatter.toJsonDecoder frontmatterDecoder)))
        decoder
        |> Decoder


{-| Get the current page's URL
-}
withUrl : Decoder (String -> value) -> Decoder value
withUrl fnDecoder =
    with (Decoder (Json.field "url" Json.string)) fnDecoder


{-| Map from one decoder to another
-}
map : (a -> value) -> Decoder a -> Decoder value
map fn (Decoder decoder) =
    Decoder (Json.map fn decoder)


toJsonDecoder : Decoder value -> Json.Decoder value
toJsonDecoder (Decoder decoder) =
    decoder
`.trimStart()

const ElmLandFile = () => `
-- 📦 Standard module for https://elm.land 🌈 --


module ElmLand.File exposing
    ( Decoder
    , json, markdown, custom
    , map
    , toJsonDecoder
    )

{-| Describe the contents for a file in the "content" folder.

@docs Decoder
@docs json, markdown, custom
@docs map

@docs toJsonDecoder

-}

import ElmLand.Markdown as Markdown
import Json.Decode
import Json.Decode.Exploration as Json


{-| Represents the content you want to access
-}
type Decoder value
    = JsonDecoder (Json.Decode.Decoder value)
    | MarkdownDecoder (Markdown.Decoder value)
    | CustomDecoder (String -> Result String value)


{-| Create a JSON file decoder
-}
json : Json.Decode.Decoder value -> Decoder value
json decoder =
    JsonDecoder decoder


{-| Create a Markdown file decoder
-}
markdown : Markdown.Decoder value -> Decoder value
markdown decoder =
    MarkdownDecoder decoder


{-| Create a custom text file decoder
-}
custom : (String -> Result String value) -> Decoder value
custom fn =
    CustomDecoder fn


{-| Map from one decoder to another
-}
map : (a -> value) -> Decoder a -> Decoder value
map fn theDecoder =
    case theDecoder of
        JsonDecoder decoder ->
            JsonDecoder (Json.Decode.map fn decoder)

        MarkdownDecoder decoder ->
            MarkdownDecoder (Markdown.map fn decoder)

        CustomDecoder toResult ->
            CustomDecoder (Result.map fn << toResult)


toJsonDecoder : Decoder value -> Json.Decoder value
toJsonDecoder decoder =
    case decoder of
        JsonDecoder jsonDecoder ->
            Json.string
                |> Json.andThen
                    (\\str ->
                        case Json.Decode.decodeString jsonDecoder str of
                            Ok value ->
                                Json.succeed value

                            Err error ->
                                Json.fail (Json.Decode.errorToString error)
                    )

        MarkdownDecoder markdownDecoder ->
            Markdown.toJsonDecoder markdownDecoder

        CustomDecoder toResult ->
            Json.string
                |> Json.andThen
                    (\\str ->
                        case toResult str of
                            Ok value ->
                                Json.succeed value

                            Err error ->
                                Json.fail error
                    )
`.trimStart()

const ElmLandFrontmatter = () => `
-- 📦 Standard module for https://elm.land 🌈 --


module ElmLand.Frontmatter exposing
    ( Decoder
    , string, int, float, bool, null
    , Date, date, time
    , object, withRequiredField, withOptionalField
    , list, maybe, dict, oneOf
    , map, map2, andThen
    , toJsonDecoder
    )

{-| Access YAML metadata at the top of a markdown file.

@docs Decoder
@docs string, int, float, bool, null
@docs Date, date, time
@docs object, withRequiredField, withOptionalField
@docs list, maybe, dict, oneOf
@docs map, map2, andThen

@docs toJsonDecoder

-}

import Dict exposing (Dict)
import Iso8601
import Json.Decode.Exploration as Json
import Time


{-| Represents the frontmatter you want to access
-}
type Decoder value
    = Decoder (Json.Decoder value)


{-| Decode a String value
-}
string : Decoder String
string =
    Decoder Json.string


{-| Decode an Int value
-}
int : Decoder Int
int =
    Decoder Json.int


{-| Decode a Float value
-}
float : Decoder Float
float =
    Decoder Json.float


{-| Decode a Bool value
-}
bool : Decoder Bool
bool =
    Decoder Json.bool


type alias Date =
    { month : Time.Month
    , day : Int
    , year : Int
    }


toDate : Time.Posix -> Date
toDate posix =
    { month = Time.toMonth Time.utc posix
    , day = Time.toDay Time.utc posix
    , year = Time.toYear Time.utc posix
    }


{-| Decode a Date in the format "YYYY-MM-DD"
-}
date : Decoder Date
date =
    Decoder (iso8601Decoder |> Json.map toDate)


iso8601Decoder : Json.Decoder Time.Posix
iso8601Decoder =
    Json.string
        |> Json.andThen
            (\\iso8601 ->
                case Iso8601.toTime iso8601 of
                    Ok posix ->
                        Json.succeed posix

                    Err _ ->
                        Json.fail "Invalid ISO 8601 date"
            )


{-| Decode a Datetime value in the format "YYYY-MM-DDTHH:mm:ss.SSSZ" format
-}
time : Decoder Time.Posix
time =
    Decoder iso8601Decoder


{-| Decode a value from "null"
-}
null : value -> Decoder value
null value =
    Decoder (Json.null value)


{-| Create a decoder for a nested object.
-}
object : value -> Decoder value
object value =
    Decoder (Json.succeed value)


{-| Shorthand for directly accessing a required frontmatter field
-}
withRequiredField :
    String
    -> Decoder field
    -> Decoder (field -> value)
    -> Decoder value
withRequiredField name (Decoder decoder) (Decoder decoder2) =
    Decoder
        (Json.map2 (|>)
            (Json.field name decoder)
            decoder2
        )


{-| Shorthand for directly accessing an optional frontmatter field
-}
withOptionalField :
    String
    -> Decoder field
    -> Decoder (Maybe field -> value)
    -> Decoder value
withOptionalField name (Decoder decoder) (Decoder decoder2) =
    Decoder
        (Json.map2 (|>)
            (Json.maybe (Json.field name decoder))
            decoder2
        )


{-| Decode a list of values
-}
list : Decoder value -> Decoder (List value)
list (Decoder decoder) =
    Decoder (Json.list decoder)


{-| Decode a generic dictionary of values
-}
dict : Decoder value -> Decoder (Dict String value)
dict (Decoder decoder) =
    Decoder (Json.dict decoder)


{-| Decode a value from one of the given decoders
-}
oneOf : List (Decoder value) -> Decoder value
oneOf decoders =
    Decoder (Json.oneOf (List.map toJsonDecoder decoders))


{-| Decode an optional value
-}
maybe : Decoder value -> Decoder (Maybe value)
maybe (Decoder decoder) =
    Decoder (Json.maybe decoder)


{-| Map from one decoder to another
-}
map : (a -> value) -> Decoder a -> Decoder value
map fn (Decoder decoder) =
    Decoder (Json.map fn decoder)


{-| Map from one decoder to another
-}
map2 : (a -> b -> value) -> Decoder a -> Decoder b -> Decoder value
map2 fn (Decoder decoder) (Decoder decoder2) =
    Decoder (Json.map2 fn decoder decoder2)


{-| Make a decoder based on the result of another decoder.
-}
andThen : (a -> Decoder value) -> Decoder a -> Decoder value
andThen fn (Decoder decoder) =
    Decoder (Json.andThen (fn >> toJsonDecoder) decoder)


{-| INTERNAL USE ONLY

Convert this decoder to a JSON decoder

-}
toJsonDecoder : Decoder value -> Json.Decoder value
toJsonDecoder (Decoder decoder) =
    decoder
`.trimStart()

export const ElmLandProgram_Markdown = `
-- 📦 Standard module for https://elm.land 🌈 --


port module ElmLand.Program exposing
    ( Program, Msg(..)
    , new
    )

{-| The default implementation of an Elm Land program.

If you want to do something fancier, feel free to copy this code
into "src/Main.elm" and use it as a starting point!

@docs Program, Msg
@docs new

-}

import Browser exposing (UrlRequest)
import Browser.Navigation as Nav exposing (Key)
import Dict exposing (Dict)
import Effect exposing (Effect)
import ElmLand.Effect
import ElmLand.Navigation
import ElmLand.Subscription
import Html
import Http
import Json.Decode as Json
import Json.Encode as Encode
import Pages
import Route exposing (Route)
import Shared
import Subscription exposing (Subscription)
import Task
import Url exposing (Url)



-- ELM LAND PROGRAM


type alias Program =
    Platform.Program Json.Value Model Msg


type alias Props =
    { onEffect : Model -> Effect Msg -> ( Model, Cmd Msg )
    , onSubscription : Subscription Msg -> Sub Msg
    , onNavigation : ElmLand.Navigation.Event -> Effect Msg
    , onUrlChanged : Url.Url -> Effect Msg
    }


{-| Create a new Elm Land program by specifying how to perform Effects
and connect Subscriptions to the Elm runtime.
-}
new :
    { onCustomEffect : Effect.CustomEffect Msg -> Url -> Key -> Shared.Model -> ( Shared.Model, Cmd Msg )
    , onCustomSubscription : Subscription.CustomSubscription Msg -> ElmLand.Subscription.Handler Subscription.Event Msg
    , onUrlChangedEvent : Url.Url -> Subscription.Event
    , onNavigationEvent : ElmLand.Navigation.Event -> Subscription.Event
    }
    -> Program
new props =
    custom
        { onEffect = ElmLand.Effect.handle props.onCustomEffect (ElmLand.Subscription.toMsgs props.onCustomSubscription)
        , onSubscription = ElmLand.Subscription.toSub props.onCustomSubscription
        , onNavigation = ElmLand.Effect.broadcast << props.onNavigationEvent
        , onUrlChanged = ElmLand.Effect.broadcast << props.onUrlChangedEvent
        }


custom :
    { onEffect :
        Subscription Msg
        -> Effect Msg
        -> Url
        -> Key
        -> Shared.Model
        -> ( Shared.Model, Cmd Msg )
    , onSubscription : Subscription Msg -> Sub Msg
    , onNavigation : ElmLand.Navigation.Event -> Effect Msg
    , onUrlChanged : Url.Url -> Effect Msg
    }
    -> Program
custom options =
    let
        onEffect : Model -> Effect Msg -> ( Model, Cmd Msg )
        onEffect model effect =
            let
                listener : Subscription Msg
                listener =
                    toSubscriptions model
            in
            options.onEffect listener effect model.url model.url_key model.shared
                |> Tuple.mapFirst (\\shared -> { model | shared = shared })

        props : Props
        props =
            { onEffect = onEffect
            , onSubscription = options.onSubscription
            , onNavigation = options.onNavigation
            , onUrlChanged = options.onUrlChanged
            }
    in
    Browser.application
        { init = init props
        , update = update props
        , view = view
        , subscriptions = subscriptions props
        , onUrlRequest = Link
        , onUrlChange = Url
        }


type alias Model =
    { data : Json.Value
    , page : Pages.Model
    , shared : Shared.Model
    , url : Url
    , url_key : Key
    , url_fromLink : Bool
    }


type alias Flags =
    { data : Json.Value
    , user : Json.Value
    }


{-|


## Expected format:

    {
        "data": <stuff from data-page attribute>,
        "user": <user-provided flags>
    }

-}
decoder : Json.Decoder Flags
decoder =
    Json.map2 Flags
        (Json.field "data" Json.value)
        (Json.field "user" Json.value)


init : Props -> Json.Value -> Url -> Key -> ( Model, Cmd Msg )
init props json url key =
    let
        flags : Flags
        flags =
            Json.decodeValue decoder json
                |> Result.withDefault (Flags Encode.null Encode.null)

        ( shared, sharedEffect ) =
            Shared.init flags.user (route url)

        ( page, pageEffect ) =
            Pages.init flags.data url shared

        model : Model
        model =
            { data = flags.data
            , shared = shared
            , page = page
            , url = url
            , url_key = key
            , url_fromLink = False
            }
    in
    Effect.batch
        [ sharedEffect
            |> Effect.map Shared
        , pageEffect
            |> Effect.map Page
        ]
        |> props.onEffect model



-- UPDATE


type Msg
    = Link UrlRequest
    | Url Url
    | Shared Shared.Msg
    | Page Pages.Msg
    | Batch (List Msg)
      -- "MARKDOWN" ROUTER ONLY
    | Loaded Bool Url (Result Http.Error Json.Value)
    | Dev_MarkdownChanged { relativePath : String, url : String, data : Json.Value }


update : Props -> Msg -> Model -> ( Model, Cmd Msg )
update props msg model =
    case msg of
        Batch msgs ->
            -- Allows you to send multiple messages at once
            -- which is useful for handling HTTP errors at the root
            -- while still sending the result to the page or original
            -- message handler.
            List.foldl
                (\\innerMsg ( m, inCmd ) ->
                    let
                        ( newModel, newCmd ) =
                            update props innerMsg m
                    in
                    ( newModel, Cmd.batch [ inCmd, newCmd ] )
                )
                ( model, Cmd.none )
                msgs

        Link urlRequest ->
            -- Occurs when a link is clicked
            case urlRequest of
                Browser.Internal url ->
                    if model.url.path == url.path then
                        ( { model | url_fromLink = True }
                        , Nav.pushUrl model.url_key (Url.toString url)
                        )

                    else
                        -- A new page needs to be initialized, but it's content
                        -- will need to be fetched first via HTTP
                        fetchPageDataForUrl url props { model | url_fromLink = True }

                Browser.External href ->
                    ( model
                    , Nav.load href
                    )

        Url url ->
            if model.url_fromLink then
                if model.url.path == url.path then
                    props.onUrlChanged model.url
                        |> props.onEffect { model | url = url, url_fromLink = False }

                else
                    ( { model | url = url, url_fromLink = False }, Cmd.none )

            else
            -- Properly handles back button and programmatic navigation
            if
                model.url.path == url.path
            then
                props.onUrlChanged model.url
                    |> props.onEffect { model | url = url, url_fromLink = False }

            else
                fetchPageDataForUrl url props { model | url_fromLink = False }

        Loaded _ url (Err httpError) ->
            props.onNavigation (ElmLand.Navigation.Failure url httpError)
                |> props.onEffect model

        Loaded needsPush url (Ok json) ->
            let
                ( newPage, pageEffect ) =
                    Pages.init json url model.shared

                ( newModel, pageCmd ) =
                    pageEffect
                        |> Effect.map Page
                        |> props.onEffect
                            { model
                                | page = newPage
                                , url = url
                                , data = json
                            }
            in
            props.onNavigation ElmLand.Navigation.Success
                |> props.onEffect newModel
                |> Tuple.mapSecond
                    (\\cmd ->
                        Cmd.batch
                            [ cmd
                            , pageCmd
                            , if needsPush then
                                Nav.pushUrl model.url_key (Url.toString url)

                              else
                                Cmd.none
                            ]
                    )

        Shared sharedMsg ->
            let
                ( newShared, sharedEffect ) =
                    Shared.update (route model.url) sharedMsg model.shared

                newModel =
                    { model | shared = newShared }
            in
            sharedEffect
                |> Effect.map Shared
                |> props.onEffect newModel

        Page pageMsg ->
            let
                ( newPage, pageEffect ) =
                    Pages.update
                        model.data
                        model.url
                        model.shared
                        pageMsg
                        model.page

                newModel =
                    { model | page = newPage }
            in
            pageEffect
                |> Effect.map Page
                |> props.onEffect newModel

        Dev_MarkdownChanged { relativePath, url, data } ->
            if url == model.url.path then
                let
                    ( newPage, pageEffect ) =
                        Pages.init data model.url model.shared

                    wasOnErrorPage : Bool
                    wasOnErrorPage =
                        Pages.isOnErrorPage model.page

                    willBeOnErrorPage : Bool
                    willBeOnErrorPage =
                        Pages.isOnErrorPage newPage

                    onlyUpdateData : ( Model, Cmd Msg )
                    onlyUpdateData =
                        ( { model | data = data }
                        , Cmd.none
                        )

                    newModel : Model
                    newModel =
                        { model | data = data, page = newPage }

                    reinitThePage : ( Model, Cmd Msg )
                    reinitThePage =
                        pageEffect
                            |> Effect.map Page
                            |> props.onEffect newModel
                in
                case ( wasOnErrorPage, willBeOnErrorPage ) of
                    ( True, True ) ->
                        -- Still on the error page, we need init
                        -- to load our new error message
                        reinitThePage

                    ( False, True ) ->
                        -- Seeing an error for the first time
                        reinitThePage

                    ( True, False ) ->
                        -- Moving from an error page to a normal page
                        reinitThePage

                    ( False, False ) ->
                        -- The data changed, but did not break the page
                        --
                        -- TODO: Check if the URL is listed in this page's decoder
                        --       so if a related file changes, we get the nice
                        --       hot-reloading experience like we do for page content!
                        --
                        onlyUpdateData

            else if Pages.isFilepathReferenced relativePath model.page then
                ( model
                , Pages.toDataRequest
                    "ELM_LAND_DEV_MARKDOWN_CHANGED"
                    (Loaded False model.url)
                    model.url
                )

            else
                ( model
                , Cmd.none
                )


subscriptions : Props -> Model -> Sub Msg
subscriptions props model =
    Sub.batch
        [ props.onSubscription (toSubscriptions model)
        , elmLand__onMarkdownChanged Dev_MarkdownChanged
        ]


toSubscriptions : Model -> Subscription Msg
toSubscriptions model =
    Subscription.batch
        [ Shared.subscriptions (route model.url) model.shared
            |> Subscription.map Shared
        , Pages.subscriptions model.data model.url model.shared model.page
            |> Subscription.map Page
        ]


view : Model -> Browser.Document Msg
view model =
    Pages.view model.data model.url model.shared model.page
        |> documentMap Page


route : Url -> Route ()
route url =
    Route.fromUrl () url



-- ELM LAND


documentMap : (a -> b) -> Browser.Document a -> Browser.Document b
documentMap fn doc =
    { title = doc.title
    , body = List.map (Html.map fn) doc.body
    }



-- SPECIFIC TO "MARKDOWN" ROUTER


{-| Received from JavaScript during development when your markdown content changes
-}
port elmLand__onMarkdownChanged : ({ relativePath : String, url : String, data : Json.Value } -> msg) -> Sub msg


elmLandPageDataTracker : String
elmLandPageDataTracker =
    "ELM_LAND_PAGE_DATA"


fetchPageDataForUrl : Url -> Props -> Model -> ( Model, Cmd Msg )
fetchPageDataForUrl url props model =
    props.onNavigation (ElmLand.Navigation.Start url)
        |> props.onEffect model
        |> Tuple.mapSecond
            (\\cmd ->
                Cmd.batch
                    [ cmd
                    , Pages.toDataRequest
                        elmLandPageDataTracker
                        (Loaded model.url_fromLink url)
                        url
                    ]
            )
`.trimStart()

const ElmLandProgram_FileBased = `
-- 📦 Standard module for https://elm.land 🌈 --


module ElmLand.Program exposing
    ( Program, Msg(..)
    , new
    )

{-| The default implementation of an Elm Land program.

If you want to do something fancier, feel free to copy this code
into "src/Main.elm" and use it as a starting point!

@docs Program, Msg
@docs new

-}

import Browser exposing (UrlRequest)
import Browser.Navigation as Nav exposing (Key)
import Effect exposing (Effect)
import ElmLand.Effect
import ElmLand.Subscription
import Html
import Json.Decode as Json
import Json.Encode as Encode
import Pages
import Route exposing (Route)
import Shared
import Subscription exposing (Subscription)
import Url exposing (Url)



-- ELM LAND PROGRAM


type alias Program =
    Platform.Program Json.Value Model Msg


type alias Props =
    { onEffect : Model -> Effect Msg -> ( Model, Cmd Msg )
    , onSubscription : Subscription Msg -> Sub Msg
    , onUrlChanged : Url -> Effect Msg
    }


{-| Create a new Elm Land program by specifying how to perform Effects
and connect Subscriptions to the Elm runtime.
-}
new :
    { onCustomEffect : Effect.CustomEffect Msg -> Url -> Key -> Shared.Model -> ( Shared.Model, Cmd Msg )
    , onCustomSubscription : Subscription.CustomSubscription Msg -> ElmLand.Subscription.Handler Subscription.Event Msg
    , onUrlChangedEvent : Url -> Subscription.Event
    }
    -> Program
new props =
    custom
        { onEffect = ElmLand.Effect.handle props.onCustomEffect (ElmLand.Subscription.toMsgs props.onCustomSubscription)
        , onSubscription = ElmLand.Subscription.toSub props.onCustomSubscription
        , onUrlChanged = props.onUrlChangedEvent >> ElmLand.Effect.broadcast
        }


custom :
    { onEffect :
        Subscription Msg
        -> Effect Msg
        -> Url
        -> Key
        -> Shared.Model
        -> ( Shared.Model, Cmd Msg )
    , onSubscription : Subscription Msg -> Sub Msg
    , onUrlChanged : Url -> Effect Msg
    }
    -> Program
custom options =
    let
        onEffect : Model -> Effect Msg -> ( Model, Cmd Msg )
        onEffect model effect =
            let
                listener : Subscription Msg
                listener =
                    toSubscriptions model
            in
            options.onEffect listener effect model.url model.url_key model.shared
                |> Tuple.mapFirst (\\shared -> { model | shared = shared })

        props : Props
        props =
            { onEffect = onEffect
            , onSubscription = options.onSubscription
            , onUrlChanged = options.onUrlChanged
            }
    in
    Browser.application
        { init = init props
        , update = update props
        , view = view
        , subscriptions = subscriptions props
        , onUrlRequest = Link
        , onUrlChange = Url
        }


type alias Model =
    { data : Json.Value
    , page : Pages.Model
    , shared : Shared.Model
    , url : Url
    , url_key : Key
    }


type alias Flags =
    { data : Json.Value
    , user : Json.Value
    }


{-|


## Expected format:

    {
        "data": <stuff from data-page attribute>,
        "user": <user-provided flags>
    }

-}
decoder : Json.Decoder Flags
decoder =
    Json.map2 Flags
        (Json.field "data" Json.value)
        (Json.field "user" Json.value)


init : Props -> Json.Value -> Url -> Key -> ( Model, Cmd Msg )
init props json url key =
    let
        flags : Flags
        flags =
            Json.decodeValue decoder json
                |> Result.withDefault (Flags Encode.null Encode.null)

        ( shared, sharedEffect ) =
            Shared.init flags.user (route url)

        ( page, pageEffect ) =
            Pages.init url shared

        model : Model
        model =
            { data = flags.data
            , shared = shared
            , page = page
            , url = url
            , url_key = key
            }
    in
    Effect.batch
        [ sharedEffect
            |> Effect.map Shared
        , pageEffect
            |> Effect.map Page
        ]
        |> props.onEffect model



-- UPDATE


type Msg
    = Link UrlRequest
    | Url Url
    | Shared Shared.Msg
    | Page Pages.Msg
    | Batch (List Msg)


update : Props -> Msg -> Model -> ( Model, Cmd Msg )
update props msg model =
    case msg of
        Batch msgs ->
            -- Allows you to send multiple messages at once
            -- which is useful for handling HTTP errors at the root
            -- while still sending the result to the page or original
            -- message handler.
            List.foldl
                (\\innerMsg ( m, inCmd ) ->
                    let
                        ( newModel, newCmd ) =
                            update props innerMsg m
                    in
                    ( newModel, Cmd.batch [ inCmd, newCmd ] )
                )
                ( model, Cmd.none )
                msgs

        Link urlRequest ->
            case urlRequest of
                Browser.Internal url ->
                    ( model
                    , Nav.pushUrl model.url_key (Url.toString url)
                    )

                Browser.External href ->
                    ( model
                    , Nav.load href
                    )

        Url url ->
            if model.url.path == url.path then
                props.onUrlChanged model.url
                    |> props.onEffect { model | url = url }

            else
                let
                    ( newPage, pageEffect ) =
                        Pages.init url model.shared

                    newModel =
                        { model | page = newPage, url = url }
                in
                pageEffect
                    |> Effect.map Page
                    |> props.onEffect newModel

        Shared sharedMsg ->
            let
                ( newShared, sharedEffect ) =
                    Shared.update (route model.url) sharedMsg model.shared

                newModel =
                    { model | shared = newShared }
            in
            sharedEffect
                |> Effect.map Shared
                |> props.onEffect newModel

        Page pageMsg ->
            let
                ( newPage, pageEffect ) =
                    Pages.update
                        model.url
                        model.shared
                        pageMsg
                        model.page

                newModel =
                    { model | page = newPage }
            in
            pageEffect
                |> Effect.map Page
                |> props.onEffect newModel


subscriptions : Props -> Model -> Sub Msg
subscriptions props model =
    props.onSubscription (toSubscriptions model)


toSubscriptions : Model -> Subscription Msg
toSubscriptions model =
    Subscription.batch
        [ Shared.subscriptions (route model.url) model.shared
            |> Subscription.map Shared
        , Pages.subscriptions model.url model.shared model.page
            |> Subscription.map Page
        ]


view : Model -> Browser.Document Msg
view model =
    Pages.view model.url model.shared model.page
        |> documentMap Page


route : Url -> Route ()
route url =
    Route.fromUrl () url



-- ELM LAND


documentMap : (a -> b) -> Browser.Document a -> Browser.Document b
documentMap fn doc =
    { title = doc.title
    , body = List.map (Html.map fn) doc.body
    }
`.trimStart()

// INERTIA/MARKDOWN ROUTER

const ElmLandNavigation = () => `
-- 📦 Standard module for https://elm.land 🌈 --


module ElmLand.Navigation exposing
    ( Event(..)
    , Problem(..)
    )

{-| This module exists for apps using the "markdown" or "inertia" router.

@docs Event
@docs Problem

-}
import Http
import Json.Decode
import Url exposing (Url)


{-| When Elm Land navigates to a new page, it must first fetch data for
that page. These events occur in "ElmLand.Program" and are provided
so you can show loading UI and gracefully handle any HTTP errors
that occur during navigation.

-}
type Event
    = Start Url
    | Success
    | Failure Url Http.Error


{-| When using Elm Land's "markdown" or "inertia" mode, there are two kinds
of errors that might prevent the app from loading a page:

  - 404: There is no data for that page (no markdown file or inertia endpoint)
  - 500: The data for that page did not match our expectations (decoder failed)

In either case, our Elm app doesn't crash– it loads the "src/Pages/ERROR\\_.elm"
page and provides the "Problem" as context.

-}
type Problem
    = Problem404
    | Problem500 Json.Decode.Error
`.trimStart()

/** @type {Packages} */
export const Packages = {
    'Http.elm': ElmLandHttp,
    'Effect.elm': ElmLandEffect,
    'Subscription.elm': ElmLandSubscription,
    'Program.elm': ElmLandProgram,
    'Meta.elm': ElmLandMeta,
    'Navigation.elm': ElmLandNavigation,
    'Content.elm': ElmLandContent,
    'Markdown.elm': ElmLandMarkdown,
    'Frontmatter.elm': ElmLandFrontmatter,
    'File.elm': ElmLandFile,
}