// @ts-check

import path from 'path'

/**
 * @param {import('.').Options} options
 * @param {string} projectRoot 
 * @param {string | any} message
 * @returns 
 */
export const toElmLandError = (options, projectRoot, message) => {

  /**
   * @param {string} moduleName 
   * @returns {string}
   */
  let relativePath = (moduleName) => {
    let absolutePath = path.join(projectRoot, 'src', ...moduleName.split('.')) + '.elm'
    return path.relative(projectRoot, absolutePath)
  }

  /**
   * Helper for highlighting what is missing from
   * a page's exposed values.
   * 
   * @param {string} moduleName 
   * @param {string} str 
   * @returns {string}
   */
  const pageExposingHighlight = (moduleName, str) => [
    '    module ' + moduleName + ' exposing',
    `        ( ${extraExposedStuff(options)}Model, Msg`,
    '        , init, update, subscriptions, view',
    '        )'
  ].join('\n').replaceAll(str, suggest(str))


  
  let isMissingExposedPageMeta = (/^I cannot find a `(Pages..+).meta` variable:$/gm).exec(message)
  if (isMissingExposedPageMeta) {
    let moduleName = isMissingExposedPageMeta[1]
    return report('MISSING PAGE META', relativePath(moduleName), [
      `I expected this module to expose a ${yellow + bold + `"meta"` + reset} function:`,
      '',
      pageExposingHighlight(moduleName, 'meta'),
      // '    ' + yellow + 'meta : Data -> ElmLand.Meta.Context -> Meta' + reset,
      '',
      'This function allows me to properly generate HTML at build time.',
      '',
      'Learn more at ' + bold + '<https://elm.land/errors/missing-page-meta>' + reset
    ])
  }

  let isInvalidPageMeta = (/decoder (.+).meta\s+\^+\s+This `meta` value is a:\s+(.+)\s+.+\s+(.+)/gm).exec(message)
  if (isInvalidPageMeta) {
    let moduleName = isInvalidPageMeta[1]
    let actual = isInvalidPageMeta[2]
    let expected = isInvalidPageMeta[3]
    let errorLength = actual.length

    return report('UNEXPECTED PAGE META', relativePath(moduleName), [
      `I ran into an unexpected type for the "${moduleName}.meta" function.`,
      '',
      'I found this type:',
      '',
      '    meta : ' + actual + reset,
      '           ' + red + '^'.repeat(errorLength) + reset,
      'but I was expecting this type instead:',
      '',
      '    meta : ' + yellow + expected + reset,
      '',
      'Please update your code to make sure that the "meta" function matches',
      `the type annotation provided above.`,
      '',
      'Learn more at <https://elm.land/errors/unexpected-page-meta>' + reset
    ])
  }

  let isMissingExposedPageDecoder = (/^I cannot find a `(Pages..+).decoder` variable:$/gm).exec(message)
  if (isMissingExposedPageDecoder) {
    let moduleName = isMissingExposedPageDecoder[1]

    let reason = options.router === 'markdown'
      ? 'guarantee your content meets\nexpectations at build time'
      : 'understand JSON that comes from your backend server'

    return report('MISSING PAGE DECODER', relativePath(moduleName), [
      `I expected this module to expose a ${yellow + bold + `"decoder"` + reset} function:`,
      '',
      // '    ' + yellow + 'decoder : ' + decoderType + reset,
      pageExposingHighlight(moduleName, 'decoder'),
      '',
      'This function allows me to ' + reason + '.',
      '',
      'Learn more at ' + bold + '<https://elm.land/errors/missing-page-decoder>' + reset
    ])
  }

  let isInvalidPageDecoder = (/FilesNeeded\.elm\s+[\s\S]+\|\s+(.+)\.decoder[\s\S]+The argument is:\s+(.+)\n/gm).exec(message)
  if (isInvalidPageDecoder) {
    let moduleName = isInvalidPageDecoder[1]
    let actual = isInvalidPageDecoder[2]
    let errorLength = actual.length

    return report('UNEXPECTED PAGE DECODER', relativePath(moduleName), [
      `I ran into an unexpected type for the "${moduleName}.decoder" function.`,
      '',
      'I found this type:',
      '',
      '    decoder : ' + actual + reset,
      '              ' + red + '^'.repeat(errorLength) + reset,
      'but I was expecting this type instead:',
      '',
      '    decoder : ' + yellow + 'ElmLand.Content.Decoder Data' + reset,
      '',
      'Please update your code to make sure that the "decoder" function matches',
      `the type annotation provided above.`,
      '',
      'Learn more at <https://elm.land/errors/unexpected-page-decoder>' + reset
    ])
  }

  let isMissingExposedModel = (/^I cannot find a \`(.+).Model` type:$/gm).exec(message)
  if (isMissingExposedModel) {
    let moduleName = isMissingExposedModel[1]

    return report('MISSING PAGE MODEL', relativePath(moduleName), [
      `I expected this module to expose a ${yellow + bold + `"Model"` + reset} type:`,
      '',
      pageExposingHighlight(moduleName, 'Model'),
      '',
      'Learn more at ' + bold + '<https://elm.land/errors/missing-page-model>' + reset
    ])
  }

  let isMissingExposedMsg = (/^I cannot find a \`(.+).Msg` type:$/gm).exec(message)
  if (isMissingExposedMsg) {
    let moduleName = isMissingExposedMsg[1]

    return report('MISSING PAGE MSG', relativePath(moduleName), [
      `I expected this module to expose a ${yellow + bold + `"Msg"` + reset} type:`,
      '',
      pageExposingHighlight(moduleName, 'Msg'),
      '',
      'Learn more at ' + bold + '<https://elm.land/errors/missing-page-msg>' + reset
    ])
  }

  let isMissingPageInit = (/^I cannot find a \`(.+).init` variable:$/gm).exec(message)
  if (isMissingPageInit) {
    let moduleName = isMissingPageInit[1]

    return report('MISSING PAGE INIT', relativePath(moduleName), [
      `I expected this module to expose an ${yellow + bold + `"init"` + reset} function:`,
      '',
      pageExposingHighlight(moduleName, 'init'),
      '',
      'Learn more at ' + bold + '<https://elm.land/errors/missing-page-init>' + reset
    ])
  }

  let isMissingPageUpdate = (/^I cannot find a \`(.+).update` variable:$/gm).exec(message)
  if (isMissingPageUpdate) {
    let moduleName = isMissingPageUpdate[1]

    return report('MISSING PAGE UPDATE', relativePath(moduleName), [
      `I expected this module to expose an ${yellow + bold + `"update"` + reset} function:`,
      '',
      pageExposingHighlight(moduleName, 'update'),
      '',
      'Learn more at ' + bold + '<https://elm.land/errors/missing-page-update>' + reset
    ])
  }

  let isMissingPageSubscriptions = (/^I cannot find a \`(.+).subscriptions` variable:$/gm).exec(message)
  if (isMissingPageSubscriptions) {
    let moduleName = isMissingPageSubscriptions[1]

    return report('MISSING PAGE SUBSCRIPRIONS', relativePath(moduleName), [
      `I expected this module to expose a ${yellow + bold + `"subscriptions"` + reset} function:`,
      '',
      pageExposingHighlight(moduleName, 'subscriptions'),
      '',
      'Learn more at ' + bold + '<https://elm.land/errors/missing-page-subscriptions>' + reset
    ])
  }

  let isMissingPageView = (/^I cannot find a \`(.+).view` variable:$/gm).exec(message)
  if (isMissingPageView) {
    let moduleName = isMissingPageView[1]

    return report('MISSING PAGE VIEW', relativePath(moduleName), [
      `I expected this module to expose a ${yellow + bold + `"view"` + reset} function:`,
      '',
      pageExposingHighlight(moduleName, 'view'),
      '',
      'Learn more at ' + bold + '<https://elm.land/errors/missing-page-view>' + reset
    ])
  }

  let hasUnexpectedPageInit = (/init = ([\s\S]+)\.init[\s\S]+This argument is a record of type:[\s\S]+, init :\s+([\s\S]+)\n    , json :[\s\S]+But `handleInitForPage`/gm).exec(message)
  if (hasUnexpectedPageInit) {
    let moduleName = hasUnexpectedPageInit[1]
    let actual = hasUnexpectedPageInit[2]
    let errorLength = actual.length

    return report('UNEXPECTED PAGE INIT', relativePath(moduleName), [
      `I ran into an unexpected type for the ${yellow + bold + `"init"` + reset} function.`,
      '',
      'I found this type:',
      '',
      '    init : ' + actual + reset,
      '           ' + red + '^'.repeat(errorLength) + reset,
      'but I was expecting this type instead:',
      '',
      '    init : ' + yellow + 'Context -> ( Model, Effect Msg )' + reset,
      '',
      'Please update your code to make sure that the "init" function matches',
      `the type annotation provided above.`,
      '',
      'Learn more at <https://elm.land/errors/unexpected-page-init>' + reset
    ])
  }

  let hasUnexpectedPageUpdate = (/update = ([\s\S]+)\.update[\s\S]+This argument is a record of type:[\s\S]+, update :\s+([\s\S]+)\n    , url :[\s\S]+But `handleUpdateForPage`/gm).exec(message)
  if (hasUnexpectedPageUpdate) {
    let moduleName = hasUnexpectedPageUpdate[1]
    let actual = hasUnexpectedPageUpdate[2]
    let errorLength = actual.length

    return report('UNEXPECTED PAGE UPDATE', relativePath(moduleName), [
      `I ran into an unexpected type for the ${yellow + bold + `"update"` + reset} function.`,
      '',
      'I found this type:',
      '',
      '    update : ' + actual + reset,
      '             ' + red + '^'.repeat(errorLength) + reset,
      'but I was expecting this type instead:',
      '',
      '    update : ' + yellow + 'Context -> Msg -> Model -> ( Model, Effect Msg )' + reset,
      '',
      'Please update your code to make sure that the "update" function matches',
      `the type annotation provided above.`,
      '',
      'Learn more at <https://elm.land/errors/unexpected-page-update>' + reset
    ])
  }

  let hasUnexpectedPageSubscriptions = (/subscriptions = ([\s\S]+)\.subscriptions[\s\S]+This argument is a record of type:[\s\S]+, subscriptions :\s+([\s\S]+)\n    , toMsg :[\s\S]+But `handleSubscriptionsForPage`/gm).exec(message)
  if (hasUnexpectedPageSubscriptions) {
    let moduleName = hasUnexpectedPageSubscriptions[1]
    let actual = hasUnexpectedPageSubscriptions[2]
    let errorLength = actual.length

    return report('UNEXPECTED PAGE SUBSCRIPTIONS', relativePath(moduleName), [
      `I ran into an unexpected type for the ${yellow + bold + `"subscriptions"` + reset} function.`,
      '',
      'I found this type:',
      '',
      '    subscriptions : ' + actual + reset,
      '                    ' + red + '^'.repeat(errorLength) + reset,
      'but I was expecting this type instead:',
      '',
      '    subscriptions : ' + yellow + 'Context -> Model -> Subscription Msg' + reset,
      '',
      'Please update your code to make sure that the "subscriptions" function matches',
      `the type annotation provided above.`,
      '',
      'Learn more at <https://elm.land/errors/unexpected-page-subscriptions>' + reset
    ])
  }

  let hasUnexpectedPageView = (/view = ([\s\S]+)\.view[\s\S]+This argument is a record of type:[\s\S]+, view :\s+([\s\S]+)\n    }[\s\S]+But `handleViewForPage`/gm).exec(message)
  if (hasUnexpectedPageView) {
    let moduleName = hasUnexpectedPageView[1]
    let actual = hasUnexpectedPageView[2]
    let errorLength = actual.length

    return report('UNEXPECTED PAGE VIEW', relativePath(moduleName), [
      `I ran into an unexpected type for the ${yellow + bold + `"view"` + reset} function.`,
      '',
      'I found this type:',
      '',
      '    view : ' + actual + reset,
      '           ' + red + '^'.repeat(errorLength) + reset,
      'but I was expecting this type instead:',
      '',
      '    view : ' + yellow + 'Context -> Model -> Browser.Document Msg' + reset,
      '',
      'Please update your code to make sure that the "view" function matches',
      `the type annotation provided above.`,
      '',
      'Learn more at <https://elm.land/errors/unexpected-page-view>' + reset
    ])
  }

  return message
}

/**
 * 
 * @param {string} title 
 * @param {string} relativePath 
 * @param {string[]} lines 
 * @returns {string}
 */
const report = (title, relativePath, lines) => {
  let maxLength = 65
  return [
    reset,'',
    cyan + '-- ' + reset + cyan + bold + title + reset + cyan + ' ' + '-'.repeat(Math.max(3, maxLength - 5 - title.length - relativePath.length)) + ' ' + reset + cyan + relativePath + reset + ' 🌈',
    '',
    ...lines,
    '',
    cyan + '-'.repeat(maxLength) + reset,
    red
  ].join('\n')
}

const reset = '\x1b[0m'
const bold = '\x1b[1m'
const dim = '\x1b[2m'
const red = '\x1b[31m'
const green = '\x1b[32m'
const yellow = '\x1b[33m'
const cyan = '\x1b[36m'

/** @type {(str: string) => string} */
const suggest = (str) => reset + yellow + str + reset

/**
 * 
 * @param {import('.').Options} options 
 * @returns {string}
 */
const extraExposedStuff = (options) =>
  options.router === 'markdown'
    ? options.output === 'mpa'
      ? 'Data, decoder\n        , meta\n        , '
      : 'Data, decoder\n        , '
    : ''