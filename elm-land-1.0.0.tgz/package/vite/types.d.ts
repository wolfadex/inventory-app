declare type DataPage = (Omit<MarkdownFile, 'kind'>) & { content: ContentFiles }

declare type ContentFile = MarkdownFile | OtherFile 

declare type ContentFiles = { [filepath: string]: ContentFile }

declare type MarkdownFile = {
  url: string
  frontmatter: unknown
  markdown: string
}

declare type OtherFile = string

declare type WorkerFilesNeededFlags = {
  url: string
}

declare type FilesNeeded = {
  files : string[]
  folders : Folder[]
}

declare type Folder = {
  path: string
  isRecursive: boolean
}

declare type WorkerMetaNeededFlags = {
  env: [string,string][]
  now: number
}

declare type PluginState = {
  projectRoot: string,
  server: null | import('vite').ViteDevServer,
  fsCache: { [filepath: string]: string }
}

declare type HtmlHeadTag = {
  name: string
  attributes: HtmlAttributes
  content: string | null
}

declare type HtmlAttributes = { [key:string]: string }

declare type HtmlOptions = {
  head: HtmlHeadTag[]
  html: HtmlAttributes
  noScriptTag?: string
  error: undefined
}

declare type Packages = {
    'Http.elm': (options: import(".").Options) => string,
    'Effect.elm': (options: import(".").Options) => string,
    'Subscription.elm': (options: import(".").Options) => string,
    'Program.elm': (options: import(".").Options) => string,
    'Meta.elm': (options: import(".").Options) => string,
    'Navigation.elm': (options: import(".").Options) => string,
    'Content.elm': (options: import(".").Options) => string,
    'Markdown.elm': (options: import(".").Options) => string,
    'Frontmatter.elm': (options: import(".").Options) => string,
    'File.elm': (options: import(".").Options) => string,
}

declare type GeneratedFile = {
  foldersToWatch: string[],
  filepath: string,
  toContent: (args: { routes: import(".").ManualRoutes }) => string
}