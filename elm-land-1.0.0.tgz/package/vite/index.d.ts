export type Options = RouterAndOutputOptions & {
  extra?: ExtraOptions
}

export type ExtraOptions = {
  useHashBasedRouting?: boolean
}

export type RouterAndOutputOptions =
  | { router: "file-based", output: "spa" }
  | { router: "file-based", output: "mpa", urls: string[] }
  | { router: "file-based", output: "js" }
  | { router: "file-based", output: "elm" }
  | { router: "markdown", output: "mpa" }
  | { router: "markdown", output: "spa" }
  | { router: "markdown", output: "js" }
  | { router: "markdown", output: "elm" }
  | { router: "inertia", output: "elm" }
  | { router: "manual", routes: ManualRoutes, output: "spa" }
  | { router: "manual", routes: ManualRoutes, output: "js" }
  | { router: "manual", routes: ManualRoutes, output: "elm" }
  | { router: "manual", routes: ManualRoutes, output: "mpa", urls: string[] }

export type ManualRoutes = {
  [url: UrlPattern]: ElmModuleName
} & {
  "*": ElmModuleName
}

export type RouterOption =
  | "manual"
  | "file-based"
  | "markdown"
  | "inertia"

export type OutputOption = "mpa" | "spa" | "js" | "elm"

/**
 * @example "/"
 * @example "/blog"
 * @example "/blog/:post"
 * @example "/blog/*"
 * @example "/contact-us"
 * @example "/settings"
 * @example "/blog/hello-world"
 */
export type UrlPattern = string

/**
 * @example "Pages.Blog"
 * @example "Pages.Blog.Post_"
 * @example "Pages.HOME_"
 * @example "Pages.ERROR_"
 */
export type ElmModuleName = string

export const elmLand: (options_?: Options) => import("vite").PluginOption

export default elmLand